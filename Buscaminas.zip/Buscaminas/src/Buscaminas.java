/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Angel Maas Samanta Chub
 */
import java.awt.*;
import java.awt.Dimension;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;

class Buscaminas extends JFrame implements ActionListener, ContainerListener {

    int fw, fh, BloqueA, BloqueB, var1, var2, Nmina, detectarmina = 0, guardarnivel = 1,
            guardabloqueA, guardarbloqueB, guardarmina = 10;
    int[] r = {-1, -1, -1, 0, 1, 1, 1, 0};
    int[] c = {-1, 0, 1, 1, 1, 0, -1, -1};
    JButton[][] blocks;
    int[][] contarmina;
    int[][] colour;
    ImageIcon[] ic = new ImageIcon[14];
    JPanel panelb = new JPanel();
    JPanel panelmt = new JPanel();
    JTextField tf_mine, tf_time;
    JButton reset = new JButton("");
    Random ranr = new Random();
    Random ranc = new Random();
    boolean check = true, starttime = false;
    Point framelocation;
    Stopwatch sw;
    MouseHendeler mh;
    Point p;

    Buscaminas() {
        super("B");
        setLocation(400, 300);

        setic();
        setpanel(1, 0, 0, 0);
        SetMenu();

        sw = new Stopwatch();

        reset.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                try {
                    sw.stop();
                    setpanel(guardarnivel, guardabloqueA, guardarbloqueB, guardarmina);
                } catch (Exception ex) {
                    setpanel(guardarnivel, guardabloqueA, guardarbloqueB, guardarmina);
                }
                reset();

            }
        });
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        show();
    }

    public void reset() {
        check = true;
        starttime = false;
        for (int i = 0; i < BloqueA; i++) {
            for (int j = 0; j < BloqueB; j++) {
                colour[i][j] = 'w';
            }
        }
    }
//Genera dor de niveles
    public void setpanel(int nivel, int setr, int setc, int setm) {
        if (nivel == 1) {
            fw = 200;
            fh = 300;
            BloqueA = 10;
            BloqueB = 10;
            Nmina = 10;
        } else if (nivel == 2) {
            fw = 320;
            fh = 416;
            BloqueA = 16;
            BloqueB = 16;
            Nmina = 70;
        } else if (nivel == 3) {
            fw = 400;
            fh = 520;
            BloqueA = 20;
            BloqueB = 20;
            Nmina = 150;
        } else if (nivel == 4) {
            fw = (20 * setc);
            fh = (24 * setr);
            BloqueA = setr;
            BloqueB = setc;
            Nmina = setm;
        }

        guardabloqueA = BloqueA;
        guardarbloqueB = BloqueB;
        guardarmina = Nmina;

        setSize(fw, fh);
        setResizable(false);
        detectarmina = Nmina;
        p = this.getLocation();

        blocks = new JButton[BloqueA][BloqueB];
        contarmina = new int[BloqueA][BloqueB];
        colour = new int[BloqueA][BloqueB];
        mh = new MouseHendeler();

        getContentPane().removeAll();
        panelb.removeAll();
        
//TABLERO DE TIEMPO Y RESULTADO
        tf_mine = new JTextField("" + Nmina, 3);
        tf_mine.setEditable(false);
        tf_mine.setFont(new Font("DigtalFont.TTF", Font.BOLD, 25));
        tf_mine.setBackground(Color.WHITE);
        tf_mine.setForeground(Color.BLACK);
        tf_mine.setBorder(BorderFactory.createLoweredBevelBorder());
        tf_time = new JTextField("000", 3);
        tf_time.setEditable(false);
        tf_time.setFont(new Font("DigtalFont.TTF", Font.BOLD, 25));
        tf_time.setBackground(Color.WHITE);
        tf_time.setForeground(Color.BLACK);
        tf_time.setBorder(BorderFactory.createLoweredBevelBorder());
        reset.setIcon(ic[11]);
        reset.setBorder(BorderFactory.createLoweredBevelBorder());

        panelmt.removeAll();
        panelmt.setLayout(new BorderLayout());
        panelmt.add(tf_mine, BorderLayout.WEST);
        panelmt.add(reset, BorderLayout.CENTER);
        panelmt.add(tf_time, BorderLayout.EAST);
        panelmt.setBorder(BorderFactory.createLoweredBevelBorder());

        panelb.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10), BorderFactory.createLoweredBevelBorder()));
        panelb.setPreferredSize(new Dimension(fw, fh));
        panelb.setLayout(new GridLayout(0, BloqueB));
        panelb.addContainerListener(this);

        for (int i = 0; i < BloqueA; i++) {
            for (int j = 0; j < BloqueB; j++) {
                blocks[i][j] = new JButton("");

                blocks[i][j].addMouseListener(mh);

                panelb.add(blocks[i][j]);

            }
        }
        reset();

        panelb.revalidate();
        panelb.repaint();
        getContentPane().setLayout(new BorderLayout());
        getContentPane().addContainerListener(this);
        getContentPane().repaint();
        getContentPane().add(panelb, BorderLayout.CENTER);
        getContentPane().add(panelmt, BorderLayout.NORTH);
        setVisible(true);
    }
//Panel Java de opciones 
    public void SetMenu() {
        JMenuBar bar = new JMenuBar();

        JMenu game = new JMenu("Niveles");

        JMenuItem menuitem = new JMenuItem("Emepezar");
        final JCheckBoxMenuItem beginner = new JCheckBoxMenuItem("Nivel 1");
        final JCheckBoxMenuItem intermediate = new JCheckBoxMenuItem("Nivel 2");
        final JCheckBoxMenuItem expart = new JCheckBoxMenuItem("Nivel 3");
        final JCheckBoxMenuItem custom = new JCheckBoxMenuItem("Personalizar");
        final JMenuItem exit = new JMenuItem("Salir");
        final JMenu help = new JMenu("Ayuda");
        final JMenuItem helpitem = new JMenuItem("Controles");

        ButtonGroup status = new ButtonGroup();

        menuitem.addActionListener(
                new ActionListener() {

                    public void actionPerformed(ActionEvent e) {

                        setpanel(1, 0, 0, 0);
                    }
                });

        beginner.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent e) {
                        panelb.removeAll();
                        reset();
                        setpanel(1, 0, 0, 0);
                        panelb.revalidate();
                        panelb.repaint();
                        beginner.setSelected(true);
                        guardarnivel = 1;
                    }
                });
        intermediate.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent e) {
                        panelb.removeAll();
                        reset();
                        setpanel(2, 0, 0, 0);
                        panelb.revalidate();
                        panelb.repaint();
                        intermediate.setSelected(true);
                        guardarnivel = 2;
                    }
                });
        expart.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent e) {
                        panelb.removeAll();
                        reset();
                        setpanel(3, 0, 0, 0);
                        panelb.revalidate();
                        panelb.repaint();
                        expart.setSelected(true);
                        guardarnivel = 3;
                    }
                });

        custom.addActionListener(new ActionListener() {

                    public void actionPerformed(ActionEvent e) {
                        Perzonalizar cus = new Perzonalizar();
                        reset();
                        panelb.revalidate();
                        panelb.repaint();
                        custom.setSelected(true);
                        guardarnivel = 4;
                    }
                });

        exit.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        helpitem.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Clic Izquiero para destapar casilla y Clic derecho para poner mina");

            }
        });

        setJMenuBar(bar);

        status.add(beginner);
        status.add(intermediate);
        status.add(expart);
        status.add(custom);
        game.add(menuitem);
        game.addSeparator();
        game.add(beginner);
        game.add(intermediate);
        game.add(expart);
        game.add(custom);
        game.addSeparator();
        game.add(exit);
        help.add(helpitem);
        bar.add(game);
        bar.add(help);

    }

    public void componentAdded(ContainerEvent ce) {
    }

    public void componentRemoved(ContainerEvent ce) {
    }

    public void actionPerformed(ActionEvent ae) {
    }

    class MouseHendeler extends MouseAdapter {

        public void mouseClicked(MouseEvent me) {
            if (check == true) {
                for (int i = 0; i < BloqueA; i++) {
                    for (int j = 0; j < BloqueB; j++) {
                        if (me.getSource() == blocks[i][j]) {
                            var1 = i;
                            var2 = j;
                            i = BloqueA;
                            break;
                        }
                    }
                }

                setmine();
                calculation();
                check = false;

            }

            showvalue(me);
            winner();

            if (starttime == false) {
                sw.Start();
                starttime = true;
            }

        }
    }

    public void winner() {
        int q = 0;
        for (int k = 0; k < BloqueA; k++) {
            for (int l = 0; l < BloqueB; l++) {
                if (colour[k][l] == 'w') {
                    q = 1;
                }
            }
        }
        if (q == 0) {
            //panelb.hide();
            for (int k = 0; k < BloqueA; k++) {
                for (int l = 0; l < BloqueB; l++) {
                    blocks[k][l].removeMouseListener(mh);
                }
            }
            sw.stop();
            JOptionPane.showMessageDialog(this, "gg");
        }
    }
//Detecar minas, y contadores
    public void showvalue(MouseEvent e) {
        for (int i = 0; i < BloqueA; i++) {
            for (int j = 0; j < BloqueB; j++) {

                if (e.getSource() == blocks[i][j]) {
                    if (e.isMetaDown() == false) {
                        if (blocks[i][j].getIcon() == ic[10]) {
                            if (detectarmina < Nmina) {
                                detectarmina++;
                            }
                            tf_mine.setText("" + detectarmina);
                        }

                        if (contarmina[i][j] == -1) {
                            for (int k = 0; k < BloqueA; k++) {
                                for (int l = 0; l < BloqueB; l++) {
                                    if (contarmina[k][l] == -1) {

    
                                        blocks[k][l].setIcon(ic[9]);
                                        blocks[k][l].setBackground(Color.BLUE);
                                        blocks[k][l].setFont(new Font("",Font.CENTER_BASELINE,8));
                                        blocks[k][l].removeMouseListener(mh);
                                    }
                                    blocks[k][l].removeMouseListener(mh);
                                }
                            }
                            sw.stop();
                            reset.setIcon(ic[12]);
                            JOptionPane.showMessageDialog(null, "Perdiste");
                        } else if (contarmina[i][j] == 0) {
                            dfs(i, j);
                        } else {
                            blocks[i][j].setIcon(ic[contarmina[i][j]]);
                            colour[i][j] = 'b';
                            break;
                        }
                    } else {
                        if (detectarmina != 0) {
                            if (blocks[i][j].getIcon() == null) {
                                detectarmina--;
                                blocks[i][j].setIcon(ic[10]);
                            }
                            tf_mine.setText("" + detectarmina);
                        }


                    }
                }

            }
        }

    }
    public void calculation() {
        int row, column;

        for (int i = 0; i < BloqueA; i++) {
            for (int j = 0; j < BloqueB; j++) {
                int value = 0;
                int R, C;
                row = i;
                column = j;
                if (contarmina[row][column] != -1) {
                    for (int k = 0; k < 8; k++) {
                        R = row + r[k];
                        C = column + c[k];

                        if (R >= 0 && C >= 0 && R < BloqueA && C < BloqueB) {
                            if (contarmina[R][C] == -1) {
                                value++;
                            }

                        }

                    }
                    contarmina[row][column] = value;

                }
            }
        }
    }
    public void dfs(int row, int col) {

        int R, C;
        colour[row][col] = 'b';

        blocks[row][col].setBackground(Color.BLACK);

        blocks[row][col].setIcon(ic[contarmina[row][col]]);

        for (int i = 0; i < 8; i++) {
            R = row + r[i];
            C = col + c[i];
            if (R >= 0 && R < BloqueA && C >= 0 && C < BloqueB && colour[R][C] == 'w') {
                if (contarmina[R][C] == 0) {
                    dfs(R, C);
                } else {
                    blocks[R][C].setIcon(ic[contarmina[R][C]]);
                    colour[R][C] = 'b';

                }
            }


        }
    }

    public void setmine() {
        int row = 0, col = 0;
        Boolean[][] flag = new Boolean[BloqueA][BloqueB];


        for (int i = 0; i < BloqueA; i++) {
            for (int j = 0; j < BloqueB; j++) {
                flag[i][j] = true;
                contarmina[i][j] = 0;
            }
        }

        flag[var1][var2] = false;
        colour[var1][var2] = 'b';

        for (int i = 0; i < Nmina; i++) {
            row = ranr.nextInt(BloqueA);
            col = ranc.nextInt(BloqueB);

            if (flag[row][col] == true) {

                contarmina[row][col] = -1;
                colour[row][col] = 'b';
                flag[row][col] = false;
            } else {
                i--;
            }
        }
    }

    public void setic() {
        String name;

        for (int i = 0; i <= 8; i++) {
            name = i + ".gif";
            ic[i] = new ImageIcon(name);
        }
        ic[9] = new ImageIcon("Mina.gif");
        ic[10] = new ImageIcon("Bandera.gif");
        ic[11] = new ImageIcon("Empezar.gif");
        ic[12] = new ImageIcon("Perdiste.gif");
    }

    public class Stopwatch extends JFrame implements Runnable {

        long startTime;
        Thread updater;
        boolean isRunning = false;
        long a = 0;
        Runnable displayUpdater = new Runnable() {

            public void run() {
                displayElapsedTime(a);
                a++;
            }
        };

        public void stop() {
            long elapsed = a;
            isRunning = false;
            try {
                updater.join();
            } catch (InterruptedException ie) {
            }
            displayElapsedTime(elapsed);
            a = 0;
        }

        private void displayElapsedTime(long elapsedTime) {

            if (elapsedTime >= 0 && elapsedTime < 9) {
                tf_time.setText("00" + elapsedTime);
            } else if (elapsedTime > 9 && elapsedTime < 99) {
                tf_time.setText("0" + elapsedTime);
            } else if (elapsedTime > 99 && elapsedTime < 999) {
                tf_time.setText("" + elapsedTime);
            }
        }

        public void run() {
            try {
                while (isRunning) {
                    SwingUtilities.invokeAndWait(displayUpdater);
                    Thread.sleep(1000);
                }
            } catch (java.lang.reflect.InvocationTargetException ite) {
                ite.printStackTrace(System.err);
            } catch (InterruptedException ie) {
            }
        }

        public void Start() {
            startTime = System.currentTimeMillis();
            isRunning = true;
            updater = new Thread(this);
            updater.start();
        }
    }

    class Perzonalizar extends JFrame implements ActionListener {

        JTextField t1, t2, t3;
        JLabel lb1, lb2, lb3;
        JButton b1, b2;
        int cr, cc, cm, actionc = 0;

        Perzonalizar() {
            super("Personalizar");
            setSize(180, 200);
            setResizable(false);
            setLocation(p);

            t1 = new JTextField();
            t2 = new JTextField();
            t3 = new JTextField();

            b1 = new JButton("Go");
            b2 = new JButton("Cancelar");

            b1.addActionListener(this);
            b2.addActionListener(this);

            lb1 = new JLabel("Linea");
            lb2 = new JLabel("Columna");
            lb3 = new JLabel("Mina");

            getContentPane().setLayout(new GridLayout(0, 2));

            getContentPane().add(lb1);
            getContentPane().add(t1);
            getContentPane().add(lb2);
            getContentPane().add(t2);
            getContentPane().add(lb3);
            getContentPane().add(t3);

            getContentPane().add(b1);
            getContentPane().add(b2);

            show();
        }

        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == b1) {
                try {
                    cr = Integer.parseInt(t1.getText());
                    cc = Integer.parseInt(t2.getText());
                    cm = Integer.parseInt(t3.getText());
                    setpanel(4, row(), column(), mine());
                    dispose();
                } catch (Exception any) {
                    JOptionPane.showMessageDialog(this, "nou");
                    t1.setText("");
                    t2.setText("");
                    t3.setText("");
                }
                //Show_rcm();
            }

            if (e.getSource() == b2) {
                dispose();
            }
        }

        public int row() {
            if (cr > 30) {
                return 30;
            } else if (cr < 10) {
                return 10;
            } else {
                return cr;
            }
        }

        public int column() {
            if (cc > 30) {
                return 30;
            } else if (cc < 10) {
                return 10;
            } else {
                return cc;
            }
        }

        public int mine() {
            if (cm > ((row() - 1) * (column() - 1))) {
                return ((row() - 1) * (column() - 1));
            } else if (cm < 10) {
                return 10;
            } else {
                return cm;
            }
        }
    }
}
